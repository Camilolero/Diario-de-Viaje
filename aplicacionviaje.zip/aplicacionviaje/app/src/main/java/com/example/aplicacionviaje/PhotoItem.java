package com.example.aplicacionviaje;

public class PhotoItem {
    private final String photoPath;
    private final String title;

    public PhotoItem(String photoPath, String title) {
        this.photoPath = photoPath;
        this.title = title;

    }
    public String getPhotoPath() {
        return photoPath;
    }

    public String getTitle() {
        return title;
    }

}