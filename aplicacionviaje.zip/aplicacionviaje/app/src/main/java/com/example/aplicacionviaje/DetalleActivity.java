package com.example.aplicacionviaje;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;
import com.google.firebase.auth.FirebaseAuth;
import androidx.appcompat.app.AppCompatActivity;

import com.example.aplicacionviaje.database.DatabaseHelper;

public class DetalleActivity extends AppCompatActivity {

    private DatabaseHelper dbHelper; // Instancia para la base de datos
    private String imagePath, title, description;
    private double latitude, longitude;
    private String weather;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detalle);

        // Instancia de DatabaseHelper
        dbHelper = new DatabaseHelper(this);

        // Referencias a los elementos del diseño
        ImageView imageView = findViewById(R.id.imageView);
        Button btnGuardar = findViewById(R.id.btnEdit); // Botón de guardar (renombrado como guardar en esta funcionalidad)
        Button btnCancelar = findViewById(R.id.btnDelete); // Botón cancelar (renombrado para esta funcionalidad)

        // Recibir datos de la actividad anterior
        Intent intent = getIntent();
        imagePath = intent.getStringExtra("imagePath"); // Ruta de la imagen
        title = intent.getStringExtra("title"); // Título
        description = intent.getStringExtra("description"); // Descripción
        latitude = intent.getDoubleExtra("latitude", 0); // Latitud
        longitude = intent.getDoubleExtra("longitude", 0); // Longitud
        weather = intent.getStringExtra("weather"); // Clima

        // Mostrar la imagen (simulación para cargar con Glide o similar)
        if (imagePath != null) {
            // Usa Glide o Picasso para cargar la imagen en el ImageView
            // Ejemplo con Glide:
            // Glide.with(this).load(imagePath).into(imageView);
        }

        // Configuración del botón "Guardar"
        btnGuardar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                guardarEnBaseDeDatos();
            }
        });

        // Configuración del botón "Cancelar"
        btnCancelar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cancelarOperacion();
            }
        });
    }

    // Método para guardar en la base de datos
    private void guardarEnBaseDeDatos() {
        if (title == null || title.isEmpty() || description == null || description.isEmpty()) {
            Toast.makeText(this, "Debe completar título y descripción", Toast.LENGTH_SHORT).show();
            return;
        }

        dbHelper.addEntry(
                FirebaseAuth.getInstance().getCurrentUser().getUid(), // UID del usuario autenticado
                title,
                description,
                imagePath,
                String.valueOf(System.currentTimeMillis()), // Fecha/hora actual
                latitude,
                longitude,
                weather
        );

        Toast.makeText(this, "Datos guardados exitosamente", Toast.LENGTH_SHORT).show();

        // Volver al menú principal
        Intent intent = new Intent(DetalleActivity.this, MenuActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
        finish();
    }

    // Método para cancelar la operación
    private void cancelarOperacion() {
        Toast.makeText(this, "Operación cancelada", Toast.LENGTH_SHORT).show();

        // Volver al menú principal sin guardar
        Intent intent = new Intent(DetalleActivity.this, MenuActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
        finish();
    }
}