package com.example.aplicacionviaje;

import android.content.Context;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.aplicacionviaje.PhotoItem;
import com.example.aplicacionviaje.R;

import java.util.List;

public class PhotoAdapter extends BaseAdapter {

    private Context context;
    private List<PhotoItem> photoList;

    public PhotoAdapter(Context context, List<PhotoItem> photoList) {
        this.context = context;
        this.photoList = photoList;
    }

    @Override
    public int getCount() {
        return photoList.size();
    }

    @Override
    public Object getItem(int position) {
        return photoList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(R.layout.item_card, parent, false);
        }

        PhotoItem photo = photoList.get(position);

        ImageView imageView = convertView.findViewById(R.id.cardImage);
        TextView titleView = convertView.findViewById(R.id.cardTitle);

        // Cargar imagen desde la ruta almacenada en SQLite
        imageView.setImageURI(Uri.parse(photo.getPhotoPath()));
        titleView.setText(photo.getTitle());

        return convertView;
    }
}
