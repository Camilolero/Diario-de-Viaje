package com.example.aplicacionviaje;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import android.widget.ListView;


import com.example.aplicacionviaje.database.DatabaseHelper;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.auth.FirebaseAuth;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.ArrayList;
import java.util.List;

public class MenuActivity extends AppCompatActivity {

    private DatabaseHelper dbHelper; // Instancia de DatabaseHelper
    private ListView listView;
    private PhotoAdapter photoAdapter;
    private List<PhotoItem> photoList;
    private String photoPath;

    private static final int REQUEST_PERMISSIONS_CODE = 100;

    private final ActivityResultLauncher<Intent> cameraLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                if (result.getResultCode() == RESULT_OK) {
                    // Redirigir a CameraActivity con la ruta de la imagen capturada
                    Intent intent = new Intent(MenuActivity.this, CameraActivity.class);
                    intent.putExtra("imagePath", photoPath);
                    startActivity(intent);
                } else {
                    Toast.makeText(MenuActivity.this, "Foto cancelada", Toast.LENGTH_SHORT).show();
                }
            }
    );

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);

        dbHelper = new DatabaseHelper(this);

        listView = findViewById(R.id.listView);
        photoList = dbHelper.getAllPhotos(); // Obtener datos de SQLite
        photoAdapter = new PhotoAdapter(this, photoList);
        listView.setAdapter(photoAdapter);

        // Configuración de otros elementos como FloatingActionButton
        FloatingActionButton fabAddPhoto = findViewById(R.id.fabAddPhoto);
        fabAddPhoto.setOnClickListener(v -> {
            // Lógica para agregar foto
        });


        // Configuración del botón flotante para agregar fotos
        fabAddPhoto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (checkPermissions()) {
                    openCamera();
                } else {
                    requestPermissions();
                }
            }
        });

        loadPhotosFromDatabase();
    }

    private boolean checkPermissions() {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED &&
                ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED;
    }

    private void requestPermissions() {
        ActivityCompat.requestPermissions(this, new String[]{
                Manifest.permission.CAMERA,
                Manifest.permission.WRITE_EXTERNAL_STORAGE,
                Manifest.permission.ACCESS_FINE_LOCATION
        }, REQUEST_PERMISSIONS_CODE);
    }

    private void openCamera() {
        try {
            // Crear un archivo para almacenar la imagen
            File photoFile = createImageFile();
            Uri photoUri = FileProvider.getUriForFile(this, "com.example.aplicacionviaje.fileprovider", photoFile);
            Intent cameraIntent = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
            cameraIntent.putExtra(android.provider.MediaStore.EXTRA_OUTPUT, photoUri);
            cameraLauncher.launch(cameraIntent);
        } catch (IOException e) {
            e.printStackTrace();
            Toast.makeText(this, "Error al crear el archivo para la imagen", Toast.LENGTH_SHORT).show();
        }
    }

    private File createImageFile() throws IOException {
        // Crear un archivo único para la imagen
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(new Date());
        String imageFileName = "JPEG_" + timeStamp + "_";
        File storageDir = getExternalFilesDir(Environment.DIRECTORY_PICTURES);
        assert storageDir != null;
        if (!storageDir.exists() && !storageDir.mkdirs()) {
            throw new IOException("No se pudo crear el directorio para las imágenes");
        }
        File image = File.createTempFile(imageFileName, ".jpg", storageDir);
        photoPath = image.getAbsolutePath();
        return image;
    }

    private void loadPhotosFromDatabase() {
        // Obtener fotos desde la base de datos
        photoList.clear();
        photoList.addAll(dbHelper.getAllPhotos()); // Metodo para obtener todas las fotos
        photoAdapter.notifyDataSetChanged(); // Notificar al adaptador que los datos cambiaron
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_PERMISSIONS_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                openCamera();
            } else {
                Toast.makeText(this, "Permisos denegados", Toast.LENGTH_SHORT).show();
            }
        }
    }
}