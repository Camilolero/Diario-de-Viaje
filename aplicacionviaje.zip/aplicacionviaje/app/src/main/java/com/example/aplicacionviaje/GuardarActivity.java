package com.example.aplicacionviaje;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.aplicacionviaje.database.DatabaseHelper;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.squareup.picasso.Picasso;

public class GuardarActivity extends AppCompatActivity {

    private ImageView imageView;
    private EditText etTitle, etDescription;
    private TextView tvCoordinates, tvWeather;
    private Button btnSave, btnCancel;

    private String photoPath, weather;
    private double latitude, longitude;
    private String userUid; // Será el UID del usuario autenticado en Firebase

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_guardar); // Asegúrate de que el archivo XML sea correcto

        // Inicializar FirebaseAuth y obtener el UID del usuario autenticado
        FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();
        if (currentUser != null) {
            userUid = currentUser.getUid();
        } else {
            Toast.makeText(this, "Usuario no autenticado", Toast.LENGTH_SHORT).show();
            finish(); // Finalizar la actividad si no hay usuario autenticado
            return;
        }

        // Referencias a los elementos del layout
        imageView = findViewById(R.id.imageView);
        etTitle = findViewById(R.id.etTitle);
        etDescription = findViewById(R.id.etDescription);
        tvCoordinates = findViewById(R.id.tvCoordinates);
        tvWeather = findViewById(R.id.tvWeather);
        btnSave = findViewById(R.id.btnSave);
        btnCancel = findViewById(R.id.btnCancel);

        // Obtener datos enviados desde CameraActivity
        Intent intent = getIntent();
        photoPath = intent.getStringExtra("imagePath");
        latitude = intent.getDoubleExtra("latitude", 0.0);
        longitude = intent.getDoubleExtra("longitude", 0.0);
        weather = intent.getStringExtra("weather");

        // Mostrar la foto en el ImageView
        if (photoPath != null) {
            Picasso.get().load("file://" + photoPath).into(imageView);
        }
        tvCoordinates.setText("Coordenadas: Lat " + latitude + ", Lon " + longitude);
        tvWeather.setText(weather);

        // Configurar el botón Guardar
        btnSave.setOnClickListener(v -> saveData());

        // Configurar el botón Cancelar
        btnCancel.setOnClickListener(v -> {
            Intent menuIntent = new Intent(GuardarActivity.this, MenuActivity.class);
            startActivity(menuIntent);
            finish(); // Finalizar la actividad actual
        });
    }

    private void saveData() {
        // Validar entrada del usuario
        String title = etTitle.getText().toString().trim();
        String description = etDescription.getText().toString().trim();

        if (title.isEmpty()) {
            Toast.makeText(this, "El título no puede estar vacío", Toast.LENGTH_SHORT).show();
            return;
        }

        if (description.isEmpty()) {
            Toast.makeText(this, "La descripción no puede estar vacía", Toast.LENGTH_SHORT).show();
            return;
        }

        // Obtener la fecha actual
        String date = new java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.getDefault()).format(new java.util.Date());

        // Guardar los datos en la base de datos
        DatabaseHelper dbHelper = new DatabaseHelper(this);
        dbHelper.addEntry(userUid, title, description, photoPath, date, latitude, longitude, weather);

        Toast.makeText(this, "Datos guardados correctamente", Toast.LENGTH_SHORT).show();

        // Redirigir al menú
        Intent menuIntent = new Intent(GuardarActivity.this, MenuActivity.class);
        startActivity(menuIntent);
        finish(); // Finalizar la actividad actual
    }
}